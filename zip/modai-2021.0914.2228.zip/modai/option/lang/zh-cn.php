<?php

return require CONF_PATH . 'lang/zh-cn.php';
