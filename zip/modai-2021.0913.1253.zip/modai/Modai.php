<?php
/*!
 * @author:大橙子
 * @website:http://maodajie.com
 * @telegram:https://t.me/maccms_tools
 * @qqcode:1570457334
 */

namespace addons\modai;

use think\Addons;

class Modai extends Addons
{
    public function install()
    {
        return true;
    }

    public function uninstall()
    {
        return true;
    }
}
