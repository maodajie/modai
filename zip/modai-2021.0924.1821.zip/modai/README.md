# Modai

#### 项目介绍
苹果CMS v10 魔袋工具箱 [http://modai.maodajie.com](http://modai.maodajie.com)

#### 免责声明
大橙苹果CMS魔袋工具箱无任何内置数据，对用户在使用过程中的信息内容本程序不负任何责任！请知悉！

#### 插件下载
[https://raw.githubusercontent.com/maodajie/modai/down/zip/modai-main.zip](https://raw.githubusercontent.com/maodajie/modai/down/zip/modai-main.zip)
[https://cdn.jsdelivr.net/gh/maodajie/modai@down/zip/modai-main.zip](https://cdn.jsdelivr.net/gh/maodajie/modai@down/zip/modai-main.zip)

#### 安装方法
1. 上传压缩包到addons文件夹
2. 解压压缩包到当前文件夹(将文件夹名称改为modai)
3. 打开苹果CMS后台->选择应用->应用市场->魔袋工具箱
4. 点击配置后自动生成快捷菜单即可使用

#### 快捷菜单
 - 魔袋工具箱,/addons/modai

#### 常见问题
1. 未生成快捷菜单请手动添加
   - 魔袋工具箱,/addons/[文件夹名称]
   - 魔袋工具箱,/addons/modai-mian
   - 魔袋工具箱,/addons/modai
2. 打开插件显示404解决办法
   - 下载苹果cms完整包,复制粘贴vendor文件夹
3. 显示致命错误...addons\__()
   - 提示这个错误为伪静态配置错误所致
   - 伪静态设置选择thinkphp即可
   - 或者完整复制maccms.conf内容修改后保存
#### 插件信息
- 插件作者：大橙子
- 联系作者：[QQ:15704757334](http://wpa.qq.com/msgrd?v=3&uin=1570457334&site=qq&menu=yes)
- 纸飞机群：[https://t.me/maccms_tools](https://t.me/maccms_tools)

#### 功能列表
1. 采集功能优化
2. 邮件批量发送
3. 轮播图片获取
4. 分集剧情获取
5. 视频角色获取
6. 视频评论获取
7. Imgur图床插件
8. 关注公众号登录