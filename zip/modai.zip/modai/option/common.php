<?php

require CONF_PATH . 'common.php';