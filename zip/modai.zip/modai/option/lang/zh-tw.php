<?php
/*!
 * @author:大橙子
 * @website:https://maodajie.com
 * @telegram:https://t.me/mubanqun
 * @qqcode:1570457334
 */
return require CONF_PATH . 'lang/zh-tw.php';
