<?php
/*!
 * @author:大橙子
 * @website:https://maodajie.com
 * @telegram:https://t.me/maccms_tool
 * @qqcode:1570457334
 */

namespace addons\modai;

use think\Addons;

class Modai extends Addons
{
    public function install()
    {
        return true;
    }

    public function uninstall()
    {
        return true;
    }
}
