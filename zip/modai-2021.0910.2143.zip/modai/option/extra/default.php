<?php

return [
    'mail' => [
        'smtp' => [],
        'tpl' => [],
    ],
    'base' => [
        'entry' => '',
        'mask' => [
            'pcre' => 'douban|iqiyi',
            'api' => 'https://i0.wp.com/',
            'state' => '1',
            'mode' => '0',
        ],
        'douban' => [
            'header' => '',
            'cookie' => '',
        ],
    ],
    'sign' => [
        'user_email' => '',
        'user_pwd' => '',
    ],
];
