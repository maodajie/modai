<?php

return require CONF_PATH . 'lang/zh-tw.php';
